*** MessagePack for Dolphin Smalltalk ***

Copyright (C) 2011 Masashi Umezawa
http://code.google.com/p/messagepack-st/

MessagePack is a compact binary serialization format (http://msgpack.org/).
"Extremely efficient object serialization library for cross-language communication. It's like JSON, but very fast and small."

- Prerequisites:
None.

- How to install:
1. Extract the zip file to Dolphin home directory.
2. From the Package Browser, select "File"->"Install Package...", then load the package "MessagePack Install.pac".

